     <!-- FOOTER -->
        <footer class="site-footer footer-opt-8">

            <div class="container">
                <div class="footer-column">
                
                    <div class="row">
                        <div class="col-md-7">
                            <div class="row">
                                <div class="col-md-4  col-sm-4">
                                    <div class="links">
                                    <h3 class="title">Grabpustak</h3>
                                    <ul>
                                        <li><a href="/aboutus">About us</a></li>
                                        <li><a href="/contact">Contact us</a></li>
                                        <li><a href="/privacy">Privacy policy</a></li>
                                        <li><a href="/terms">Terms & condition</a></li>
                                        <li><a href="http://blog.grabpustak.in">Blog</a></li>
                                    </ul>
                                    </div>
                                </div>
                                <div class="col-md-4  col-sm-4">
                                    <div class="links">
                                    <h3 class="title">Book Store</h3>
                                    <ul>
                                        <li><a href="#">New In</a></li>
                                        <li><a href="/search?f=books">Books</a></li>
                                        <li><a href="/search?f=old-papers">Old Papers</a></li>
                                        <li><a href="/search?f=student-notes,teacher-notes">Class Notes</a></li>
                                    </ul>
                                    </div>
                                </div>
                                <div class="col-md-4  col-sm-4">
                                    <div class="links">
                                    <h3 class="title">Publishers</h3>
                                    <ul>
                                        <li><a href="/cp">Want to add book?</a></li>
                                        <li><a href="/faq">FAQ</a></li>
                                        <li><a href="/help">Help</a></li>
                                    </ul>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        
                        <div class="col-md-5 col-sm-12">
                            <div class="block-social">
                                <div class="block-title">Let’s Socialize </div>
                                <div class="block-content">
                                    <a href="https://www.facebook.com/GrabPustak/"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                    <a href="https://twitter.com/GrabPustak"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                    <a href="https://in.linkedin.com/in/grabpustak"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                    <a href="https://plus.google.com/u/0/116930557410099522349"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                    <a href="https://www.youtube.com/channel/UCgAstvI9KXBupNAczxOeMRw"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                                </div>
                            </div>

                            <div class="block-newletter">
                                <div class="block-title">SIGN UP FOR NEWSLETTER</div>
                                <div class="block-content">
                                    <form>
                                    <div class="input-group">
                                        <input type="text" class="form-control" placeholder="Your Email Address">
                                        <span class="input-group-btn">
                                            <button class="btn btn-subcribe" type="button"><span>Subcribe</span></button>
                                        </span>
                                    </div>
                                </form>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="copyright">
                    
                    Copyright © 2016 Grabpustak . All Rights Reserved. Crafted in India 
                   
                </div>

            </div>
        </footer><!-- end FOOTER -->    
        
        <!--back-to-top  -->
        <a href="#" class="back-to-top">
            <i aria-hidden="true" class="fa fa-angle-up"></i>
        </a>
        
    </div>

    <script src="/static/site/select2/js/select2.full.js"></script>    
    <!-- Boostrap --> 
    <script type="text/javascript" src="/static/site/js/bootstrap.js"></script>

    <!-- sticky -->
    <script type="text/javascript" src="/static/site/js/jquery.sticky.js"></script>

    <!-- OWL CAROUSEL Slider -->    
    <script type="text/javascript" src="/static/site/js/owl.carousel.js"></script>

    <!-- Countdown -->    
    
    <script type="text/javascript" src="/static/site/js/jquery.countdown.min.js"></script>
    
    
    <!-- modernizr -->
    <script src="/static/site/js/modernizr.js"></script>

   
    <!-- elevatezoom --> 
    <script type="text/javascript" src="/static/site/js/jquery.elevateZoom.min.js"></script>

    <!-- fancybox -->
    <script src="/static/site/js/fancybox/source/jquery.fancybox.pack.js"></script>
    <script src="/static/site/js/fancybox/source/helpers/jquery.fancybox-media.js"></script>
    <script src="/static/site/js/fancybox/source/helpers/jquery.fancybox-thumbs.js"></script>

    <!-- arcticmodal -->
    <script src="/static/site/js/arcticmodal/jquery.arcticmodal.js"></script>

    <!-- Chosen jquery-->    
    
    <script type="text/javascript" src="/static/site/js/chosen.jquery.js"></script>
    
    <!-- Main -->  
    <script type="text/javascript" src="/static/site/js/main.js"></script>

  

<!-- Piwik -->
<script type="text/javascript">
  var _paq = _paq || [];
  _paq.push(['trackPageView']);
  _paq.push(['enableLinkTracking']);
  (function() {
    var u="//grabpustak.in/piwik/";
    _paq.push(['setTrackerUrl', u+'piwik.php']);
    _paq.push(['setSiteId', '3']);
    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
  })();
</script>
<noscript><p><img src="//grabpustak.in/piwik/piwik.php?idsite=3" style="border:0;" alt="" /></p></noscript>


<?php if(isset($reader) && !empty($reader)): ?>
<script type="text/javascript" src="/static/reader/wow_book.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
     // $('#book_read_modal').on('show.bs.modal', function () {

     $('#book_').wowBook({
         height: 580,
         width: 800,
         centeredWhenClosed: true
             // ,keyboardNavigation : true
             ,
         hardcovers: true,
         forceBasicPage: true,
         flipSoundFile: ["page-flip.mp3", "page-flip.ogg"],
         flipSoundPath: "/static/reader/sound/",
         turnPageDuration: 100,
         numberedPages: [1, -2],
         controls: {
             zoomIn: '#zoomin',
             zoomOut: '#zoomout',
             next: '#next',
             back: '#back',
             first: '#first',
             last: '#last',
             slideShow: '#slideshow',
             flipSound: '#flipsound',
             thumbnails: '#thumbs',
             fullscreen: '#fullscreen'
         },
         thumbnailsPosition: 'right',
         onFullscreenError: function() {
             var msg = "Fullscreen failed.";
             if (self != top) msg = "The frame is blocking full screen mode. Click on 'remove frame' button above and try to go full screen again."
             alert(msg);
         },
         onShowPage: function(book, page, index) {
             if (index == 10) {
                 show_adv(index);
             }
         }
     }).css({
         'display': 'none',
         'margin': 'auto'
     }).fadeIn(1000);

     $("#cover").click(function() {
         $.wowBook("#book_").advance();
     });

     var book = $.wowBook("#book_");

     function show_adv(id) {
         if (($("#book_read_modal").data('bs.modal') || {}).isShown) {
             $.ajax({
                     url: '/load',
                     type: 'get',
                     dataType: 'json',
                 })
                 .done(function(data) {

                     data = data[0];
                     var book = $.wowBook("#book_");
                     book.setKeyboard(false);

                     _paq.push(['setDocumentTitle', book_data_+ ' / a - ' + data.ad_id + ' | ' + data.ad_title]);
                     _paq.push(['trackPageView']);
                     _paq.push(['setDocumentTitle', 'a - '+ data.ad_id + ' | ' + data.ad_title + ' / ' + book_data_]);
                     _paq.push(['trackPageView']);
                     swal({
                             title: data.ad_title,
                             text: "<img src=" + data.ad_image + " alt=" + data.ad_title + ">",
                             html: true,
                             click_url: data.ad_click_url,
                             clickable: true,
                             timer: 10000,
                             showConfirmButton: false
                         },
                         function() {
                             swal.close();
                             book.setKeyboard(true);
                         });
                 })
                 .fail(function() {
                     console.log("error");
                 })
                 .always(function() {
                     console.log("complete");
                 });



         }
     }

     function rebuildThumbnails() {
         book.destroyThumbnails()
         book.showThumbnails()
         $("#thumbs_holder").css("marginTop", -$("#thumbs_holder").height() / 2)
     }
     $("#thumbs_position button").on("click", function() {
         var position = $(this).text().toLowerCase()
         if ($(this).data("customized")) {
             position = "top"
             book.opts.thumbnailsParent = "#thumbs_holder";
         } else {
             book.opts.thumbnailsParent = "body";
         }
         book.opts.thumbnailsPosition = position
         rebuildThumbnails();
     })
     $("#thumb_automatic").click(function() {
         book.opts.thumbnailsSprite = null
         book.opts.thumbnailWidth = null
         rebuildThumbnails();
     })
     $("#thumb_sprite").click(function() {
         book.opts.thumbnailsSprite = "/static/reader/images/thumbs.jpg"
         book.opts.thumbnailWidth = 136
         rebuildThumbnails();
     })
     $("#thumbs_size button").click(function() {
             var factor = 0.02 * ($(this).index() ? -1 : 1);
             book.opts.thumbnailScale = book.opts.thumbnailScale + factor;
             rebuildThumbnails();
         })
         // })
     $('#book_read_modal').on('hide.bs.modal', function() {
         var book = $.wowBook("#book_");
         book.setKeyboard(false);
     })
     $('#book_read_modal').on('show.bs.modal', function() {
         var book = $.wowBook("#book_");
         book.setKeyboard(true);
     })

     $(document).on('click', '.sweet-alert', function(event) {
         event.preventDefault();
         if ($(this).data('clickable')) window.open($(this).data('click_url'), '_blank');
     });

 });
     jQuery(document).ready(function($) {
    if(jQuery.query.get('handle')){
       $('#book_read_modal').modal('show');
         var book = $.wowBook("#book_");
         book.setKeyboard(true);
       // console.log('autostart',true);
    }

});
</script>

<script src="/static/reader/js/plugins.js"></script>
<!-- <script src="/static/js/magnific_popup/jquery.magnific-popup.min.js"></script> -->

<?php  endif; ?>

</body>
</html>

<?php 
if (! function_exists('create_links'))
{
	function create_links($param)
	{
	 
	}
}
?>

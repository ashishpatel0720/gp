<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Base extends CI_Controller {
	public $header_data=[];
    public function __construct()
    {
    	parent::__construct();
    	$this->load->helper('url');
    	$this->load->helper('form');
    	$this->load->helper('emailcontent');
    	$this->load->model('bookmodel');
    	// $this->header_data['menu'] = $this->basemodel->getMenu();
    	$this->footer_data['reader'] = false;
    	$this->header_data['reader'] = false;
    	$this->header_data['page_type'] = false;

//	   	$this->footer_data['recent_blogs'] = $this->basemodel->getTopBlogByViews(4);
	    $this->footer_data['map'] = false;
    	$this->load->library('form_validation');
    	$this->categories= [];
    	// $this->output->cache(3);
    	$books = ($this->bookmodel->fetchCategories());
    	foreach ($books as $key => $value) {
			$this->categories[$value['main_category_title']][$value['sub_category_title']][] = $value['subject_title']; 
		}
		$this->header_data['categories'] = $this->categories;

    }
	public function index()
	{
		error_reporting(1);
 		$this->header_data['page_title'] = "Home | Grabpustak";
 		$this->header_data['page_type'] ="cms-index-index index-opt-8";
		$this->header_data['meta_title'] = "Home | Grabpustak ";
		$this->header_data['description']="Grabpustak is the online repository for books. Which contains the large variety of children, college books and large dataset of the nobels.";
		$this->footer_data['facebook'] = true;
		$this->footer_data['map'] = true;

		$home_data['top_books'] = $this->bookmodel->getBooksByLimit(5);

 	    $this->load->view('site/header_home',$this->header_data);
		$this->load->view('site/home',$home_data);
		$this->load->view('site/footer',$this->footer_data);
	}

 
  // function check_name($name){
  //       // if(preg_match("/^[a-zA-Z ]*$/", $name)){
  //       if(preg_match("/^\w+$/", $name)){
  //       	return true;
  //       }
  //       return false;
  //   }
 
	public function about()
	{
		error_reporting(1);
		
		$this->header_data['page_title'] = "Home | Grabpustak";
		$this->header_data['meta_title'] = "Home | Grabpustak ";
		$this->header_data['description']="Grabpustak is the online repository for books. Which contains the large variety of children, college books and large dataset of the nobels.";
		$this->footer_data['facebook'] = true;
		$this->footer_data['map'] = true;
		
		
 	    $this->load->view('site/header',$this->header_data);
		$this->load->view('site/about',$home_data);
		$this->load->view('site/footer',$this->footer_data);
	}
	public function contact()
	{
		error_reporting(1);
		$this->header_data['page_title'] = "Home | Grabpustak";
		$this->header_data['meta_title'] = "Home | Grabpustak ";
		$this->header_data['description']="Grabpustak is the online repository for books. Which contains the large variety of children, college books and large dataset of the nobels.";
		$this->footer_data['facebook'] = true;
		$this->footer_data['map'] = true;
	
 	    $this->load->view('site/header',$this->header_data);
		$this->load->view('site/contact',$home_data);
		$this->load->view('site/footer',$this->footer_data);
	}

	// public function show404(){
	// 	$this->load->view('header',$header_data);
	// 	$this->load->view('errors/404.php',$data);
	// 	$this->load->view('footer',$this->footer_data);
	// }
	
	public function loadAds()
	{
		$ads_data = $this->bookmodel->getAd();
		echo $this->output->set_content_type('application/json')->set_output(json_encode($ads_data));
	}




}
